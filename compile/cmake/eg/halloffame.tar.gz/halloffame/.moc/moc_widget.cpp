/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../include/widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[23];
    char stringdata0[323];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Widget"
QT_MOC_LITERAL(1, 7, 7), // "udpBind"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 11), // "hideAllSlot"
QT_MOC_LITERAL(4, 28, 15), // "faguangShowSlot"
QT_MOC_LITERAL(5, 44, 1), // "i"
QT_MOC_LITERAL(6, 46, 17), // "guangxianShowSlot"
QT_MOC_LITERAL(7, 64, 16), // "xingxingShowSlot"
QT_MOC_LITERAL(8, 81, 16), // "xunzhangShowSlot"
QT_MOC_LITERAL(9, 98, 16), // "pianmingShowSlot"
QT_MOC_LITERAL(10, 115, 19), // "mingrentangShowSlot"
QT_MOC_LITERAL(11, 135, 23), // "zhengzaijinxingShowSlot"
QT_MOC_LITERAL(12, 159, 21), // "huizhanglishiShowSlot"
QT_MOC_LITERAL(13, 181, 12), // "zhouShowSlot"
QT_MOC_LITERAL(14, 194, 11), // "yueShowSlot"
QT_MOC_LITERAL(15, 206, 10), // "jiShowSlot"
QT_MOC_LITERAL(16, 217, 12), // "yuanShowSlot"
QT_MOC_LITERAL(17, 230, 17), // "yuanguangShowSlot"
QT_MOC_LITERAL(18, 248, 13), // "kuangShowSlot"
QT_MOC_LITERAL(19, 262, 23), // "qiehuantouxiangShowSlot"
QT_MOC_LITERAL(20, 286, 16), // "touxiangShowSlot"
QT_MOC_LITERAL(21, 303, 13), // "shuziShowSlot"
QT_MOC_LITERAL(22, 317, 5) // "medal"

    },
    "Widget\0udpBind\0\0hideAllSlot\0faguangShowSlot\0"
    "i\0guangxianShowSlot\0xingxingShowSlot\0"
    "xunzhangShowSlot\0pianmingShowSlot\0"
    "mingrentangShowSlot\0zhengzaijinxingShowSlot\0"
    "huizhanglishiShowSlot\0zhouShowSlot\0"
    "yueShowSlot\0jiShowSlot\0yuanShowSlot\0"
    "yuanguangShowSlot\0kuangShowSlot\0"
    "qiehuantouxiangShowSlot\0touxiangShowSlot\0"
    "shuziShowSlot\0medal"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  194,    2, 0x0a /* Public */,
       3,    0,  195,    2, 0x0a /* Public */,
       4,    1,  196,    2, 0x0a /* Public */,
       4,    0,  199,    2, 0x2a /* Public | MethodCloned */,
       6,    1,  200,    2, 0x0a /* Public */,
       6,    0,  203,    2, 0x2a /* Public | MethodCloned */,
       7,    1,  204,    2, 0x0a /* Public */,
       7,    0,  207,    2, 0x2a /* Public | MethodCloned */,
       8,    1,  208,    2, 0x0a /* Public */,
       8,    0,  211,    2, 0x2a /* Public | MethodCloned */,
       9,    1,  212,    2, 0x0a /* Public */,
       9,    0,  215,    2, 0x2a /* Public | MethodCloned */,
      10,    1,  216,    2, 0x0a /* Public */,
      10,    0,  219,    2, 0x2a /* Public | MethodCloned */,
      11,    1,  220,    2, 0x0a /* Public */,
      11,    0,  223,    2, 0x2a /* Public | MethodCloned */,
      12,    1,  224,    2, 0x0a /* Public */,
      12,    0,  227,    2, 0x2a /* Public | MethodCloned */,
      13,    1,  228,    2, 0x0a /* Public */,
      13,    0,  231,    2, 0x2a /* Public | MethodCloned */,
      14,    1,  232,    2, 0x0a /* Public */,
      14,    0,  235,    2, 0x2a /* Public | MethodCloned */,
      15,    1,  236,    2, 0x0a /* Public */,
      15,    0,  239,    2, 0x2a /* Public | MethodCloned */,
      16,    1,  240,    2, 0x0a /* Public */,
      16,    0,  243,    2, 0x2a /* Public | MethodCloned */,
      17,    1,  244,    2, 0x0a /* Public */,
      17,    0,  247,    2, 0x2a /* Public | MethodCloned */,
      18,    1,  248,    2, 0x0a /* Public */,
      18,    0,  251,    2, 0x2a /* Public | MethodCloned */,
      19,    1,  252,    2, 0x0a /* Public */,
      19,    0,  255,    2, 0x2a /* Public | MethodCloned */,
      20,    1,  256,    2, 0x0a /* Public */,
      20,    0,  259,    2, 0x2a /* Public | MethodCloned */,
      21,    1,  260,    2, 0x0a /* Public */,
      21,    0,  263,    2, 0x2a /* Public | MethodCloned */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Widget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->udpBind(); break;
        case 1: _t->hideAllSlot(); break;
        case 2: _t->faguangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 3: _t->faguangShowSlot(); break;
        case 4: _t->guangxianShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 5: _t->guangxianShowSlot(); break;
        case 6: _t->xingxingShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 7: _t->xingxingShowSlot(); break;
        case 8: _t->xunzhangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 9: _t->xunzhangShowSlot(); break;
        case 10: _t->pianmingShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 11: _t->pianmingShowSlot(); break;
        case 12: _t->mingrentangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 13: _t->mingrentangShowSlot(); break;
        case 14: _t->zhengzaijinxingShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 15: _t->zhengzaijinxingShowSlot(); break;
        case 16: _t->huizhanglishiShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 17: _t->huizhanglishiShowSlot(); break;
        case 18: _t->zhouShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 19: _t->zhouShowSlot(); break;
        case 20: _t->yueShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 21: _t->yueShowSlot(); break;
        case 22: _t->jiShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 23: _t->jiShowSlot(); break;
        case 24: _t->yuanShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 25: _t->yuanShowSlot(); break;
        case 26: _t->yuanguangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 27: _t->yuanguangShowSlot(); break;
        case 28: _t->kuangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 29: _t->kuangShowSlot(); break;
        case 30: _t->qiehuantouxiangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 31: _t->qiehuantouxiangShowSlot(); break;
        case 32: _t->touxiangShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 33: _t->touxiangShowSlot(); break;
        case 34: _t->shuziShowSlot((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 35: _t->shuziShowSlot(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Widget::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_Widget.data,
    qt_meta_data_Widget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 36;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
