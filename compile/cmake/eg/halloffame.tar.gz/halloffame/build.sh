#!/bin/bash

apt-get install -y debconf-utils libjsoncpp-dev
mkdir build_ && cd build_
cmake .. -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Release
make
make install
make package
