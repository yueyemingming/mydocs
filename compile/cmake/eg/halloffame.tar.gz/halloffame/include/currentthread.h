#ifndef CURRENTTHREAD_H
#define CURRENTTHREAD_H

#include <QThread>
#include <QtSql>

#include "widget.h"

class Widget ;

class CurrentThread : public QThread
{
    Q_OBJECT

public:
    explicit CurrentThread(Widget *pWin = nullptr);
    ~CurrentThread();

    Widget* pWin;
    QUdpSocket* mSocket;
    QSqlDatabase db ;

    int running_session_id ;

    int state_prev ;
    int state_next ;
    int session_prev ;
    int session_next ;

    uint32_t rank1_seat;
    uint32_t rank2_seat;
    uint32_t rank3_seat;

    uint32_t score1;
    uint32_t score2;
    uint32_t score3;

    bool isFirstTime;
    bool isGameHasStarted;

    void run();
    bool connect_db() ;
    void getAvatar(const int rank1_seat,
                   const int rank2_seat,
                   const int rank3_seat);

    void stateToggle();
    void touXiangToggle();

signals:
    void udpBind() ;
    void sigHideAll() ;
    void sigTouxiangShow();

public slots:
    void getScore();
};

#endif // CURRENTTHREAD_H
