#ifndef HISTORYTHREAD_H
#define HISTORYTHREAD_H

#include <QThread>
#include <QtSql>

#include "widget.h"

class Widget ;

class HistoryThread : public QThread
{
    Q_OBJECT

public:
    explicit HistoryThread(Widget *pWin = nullptr);
    ~HistoryThread();

    Widget* pWin;
    QSqlDatabase db ;
    bool isFirstTime;

    void run();
    bool connect_db() ;

    void getZhouData() ;
    void getYueData() ;
    void getJiData() ;

    QString getZhouBegin();
    QString getZhouEnd();
    QString getYueBegin();
    QString getYueEnd();
    QString getJiBegin();
    QString getJiEnd();

    void stateToggle();
    void zhouState();
    void yueState();
    void jiState();
    void touXiangToggle();   //切换头像和分数

signals:
    void sigHideAll();
    void sigTouxiangShow();
};

#endif // HISTORYTHREAD_H
