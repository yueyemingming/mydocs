#ifndef KUANG_H
#define KUANG_H

#include <QThread>

#include "widget.h"

class Widget ;

class Kuang : public QThread
{
    Q_OBJECT

public:
    explicit Kuang(Widget *pWin = nullptr);
    ~Kuang() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // KUANG_H
