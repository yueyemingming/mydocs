#ifndef MINGRENTANG_H
#define MINGRENTANG_H

#include <QThread>

#include "widget.h"

class Widget ;

class MingRenTang : public QThread
{
    Q_OBJECT

public:
    explicit MingRenTang(Widget *pWin = nullptr);
    ~MingRenTang() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // MINGRENTANG_H
