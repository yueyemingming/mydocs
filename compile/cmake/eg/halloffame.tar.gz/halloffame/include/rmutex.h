#ifndef RMUTEX_H
#define RMUTEX_H

#include <QMutex>
//#include <iostream>

class rmutex
{
public:
    rmutex( QMutex &lock )
        : m_lock( lock )
    {
        //std::cout << "lock " ;
        m_lock.lock();
        //std::cout << "locked" << std::endl;
    }

    ~rmutex( )
    {
        m_lock.unlock();
        //std::cout << "unlocked" << std::endl;
    }

private:
    QMutex& m_lock;
};

#endif // RMUTEX_H
