#ifndef SHUZI_H
#define SHUZI_H

#include <QThread>

#include "widget.h"

class Widget ;

class ShuZi : public QThread
{
    Q_OBJECT

public:
    explicit ShuZi(Widget *pWin = nullptr);
    ~ShuZi() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int i = -1);
};

#endif // SHUZI_H
