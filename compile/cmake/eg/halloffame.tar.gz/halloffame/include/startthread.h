#ifndef STARTTHREAD_H
#define STARTTHREAD_H

#include <QThread>
#include "widget.h"

class Widget ;

class StartThread : public QThread
{
    Q_OBJECT

public:
    explicit StartThread(Widget *pWin = nullptr);
    ~StartThread() { pWin = nullptr; }

    Widget* pWin;

    void run();

signals:
    void sigHideAll();
};

#endif // STARTTHREAD_H
