#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>
#include <QMutex>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <thread>
#include <QString>
#include <QUdpSocket>
#include <atomic>
#include "faguang.h"
#include "guangxian.h"
#include "xingxing.h"
#include "xunzhang.h"
#include "mingrentang.h"
#include "zhengzaijinxing.h"
#include "huizhanglishi.h"
#include "zhou.h"
#include "yue.h"
#include "ji.h"
#include "kuang.h"
#include "yuan.h"
#include "yuanguang.h"
#include "qiehuantouxiang.h"
#include "shuzi.h"
#include "pianming.h"

#include "historythread.h"
#include "currentthread.h"
#include "startthread.h"

#include "rmutex.h"

#include "jsoncpp/json/reader.h"
#include "jsoncpp/json/json.h"

#define config_file "config.json"

const int JIN = 0 ;
const int YIN = 1 ;
const int TONG = 2;

const int RUNNING = 0;
const int OVER = 1;
const int ZHOU = 2;
const int YUE = 3;
const int JI = 4;

extern QMutex mutex;

class FaGuang;
class GuangXian;
class XingXing;
class XunZhang;
class MingRenTang;

class ZhengZaiJinXing;
class HuiZhangLiShi;
class Zhou;
class Yue;
class Ji;

class Kuang;
class Yuan;
class YuanGuang;

class QieHuanTouXiang;
class ShuZi;

class PianMing;

class HistoryThread;
class CurrentThread;

class StartThread;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;

public:
    QGraphicsOpacityEffect* effectPianMing;
    QGraphicsOpacityEffect* effectKuangJin;
    QGraphicsOpacityEffect* effectKuangYin;
    QGraphicsOpacityEffect* effectKuangTong;
    QGraphicsOpacityEffect* effectKuangXiaJin;
    QGraphicsOpacityEffect* effectKuangXiaYin;
    QGraphicsOpacityEffect* effectKuangXiaTong;

    QPixmap picJin ;
    QPixmap picYin ;
    QPixmap picTong ;

    QString scoreJin ;
    QString scoreYin ;
    QString scoreTong ;

    std::atomic<int> game_state{-1} ;
    QTime gameOverTime;

    QString config_host;
    QString config_port;
    QString config_user;
    QString config_password;
    QString config_database;
    QString config_db_reconnect_interval;
    QString config_game_event_interval;
    QString config_game_over_wait_interval;
    QString config_history_refresh_interval;
    QString config_game_event_send_port;
    QString config_game_event_receive_port;

    FaGuang* faguangThread;
    GuangXian* guangxianThread;
    XingXing* xingxingThread;
    XunZhang* xunzhangThread;
    MingRenTang* mingrentangThread;

    ZhengZaiJinXing* zhengzaijinxingThread;
    HuiZhangLiShi* huizhanglishiThread;
    Zhou* zhouThread;
    Yue* yueThread;
    Ji* jiThread;

    Kuang* kuangThread;
    Yuan* yuanThread;
    YuanGuang* yuanguangThread;

    QieHuanTouXiang* qiehuantouxiangThread;
    ShuZi* shuziThread;

    PianMing* pianmingThread;



    HistoryThread* historyThread;
    CurrentThread* currentThread;

    StartThread* startThread;

    bool get_config() ;

public slots:

    void udpBind();

    void hideAllSlot();

    void faguangShowSlot(const int i = 0);
    void guangxianShowSlot(const int i = 0);
    void xingxingShowSlot(const int i = 0);
    void xunzhangShowSlot(const int i = 0);
    void pianmingShowSlot(const int i = 0) ;
    void mingrentangShowSlot(const int i = 0);
    void zhengzaijinxingShowSlot(const int i = 0) ;
    void huizhanglishiShowSlot(const int i = 0) ;
    void zhouShowSlot(const int i = 0) ;
    void yueShowSlot(const int i = 0) ;
    void jiShowSlot(const int i = 0) ;
    void yuanShowSlot(const int i = 0) ;
    void yuanguangShowSlot(const int i = 0) ;
    void kuangShowSlot(const int i = 0) ;
    void qiehuantouxiangShowSlot(const int i = 0) ;
    void touxiangShowSlot(const int i = 0) ;
    void shuziShowSlot(const int medal = 0) ;
};

#endif // WIDGET_H
