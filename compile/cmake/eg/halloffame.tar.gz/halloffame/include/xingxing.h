#ifndef XINGXING_H
#define XINGXING_H

#include <QThread>

#include "widget.h"

class Widget ;

class XingXing : public QThread
{
    Q_OBJECT

public:
    explicit XingXing(Widget *pWin = nullptr);
    ~XingXing() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // XINGXING_H
