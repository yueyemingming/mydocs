#ifndef XUNZHANG_H
#define XUNZHANG_H

#include <QThread>

#include "widget.h"

class Widget ;

class XunZhang : public QThread
{
    Q_OBJECT

public:
    explicit XunZhang(Widget *pWin = nullptr);
    ~XunZhang() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // XUNZHANG_H
