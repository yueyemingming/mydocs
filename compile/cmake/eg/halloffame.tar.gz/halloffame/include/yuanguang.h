#ifndef YUANGUANG_H
#define YUANGUANG_H

#include <QThread>

#include "widget.h"

class Widget ;

class YuanGuang : public QThread
{
    Q_OBJECT

public:
    explicit YuanGuang(Widget *pWin = nullptr);
    ~YuanGuang() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // YUANGUANG_H
