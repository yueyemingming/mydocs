#ifndef YUE_H
#define YUE_H

#include <QThread>

#include "widget.h"

class Widget ;

class Yue : public QThread
{
    Q_OBJECT

public:
    explicit Yue(Widget *pWin = nullptr);
    ~Yue() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // YUE_H
