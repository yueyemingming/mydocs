#ifndef ZHENGZAIJINXING_H
#define ZHENGZAIJINXING_H

#include <QThread>

#include "widget.h"

class Widget ;

class ZhengZaiJinXing : public QThread
{
    Q_OBJECT

public:
    explicit ZhengZaiJinXing(Widget *pWin = nullptr);
    ~ZhengZaiJinXing() { pWin = nullptr ; }

    static const int max_pic_size ;
    Widget* pWin;

    void run();

signals:
    void sigShow(const int);
};

#endif // ZHENGZAIJINXING_H
