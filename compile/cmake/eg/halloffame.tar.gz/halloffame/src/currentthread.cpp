#include "currentthread.h"
#include "Common.pb.h"

CurrentThread::CurrentThread(Widget* p) : pWin(p),
    mSocket(new QUdpSocket),

    state_prev(-1),
    state_next(-1),
    session_prev(-1),
    session_next(-1),

    rank1_seat(0),
    rank2_seat(0),
    rank3_seat(0),

    score1(0),
    score2(0),
    score3(0),

    isFirstTime(true),
    isGameHasStarted(false)
{
    connect(this, SIGNAL(udpBind()), pWin, SLOT(udpBind()));
    connect(mSocket, SIGNAL(readyRead()), this, SLOT(getScore()));

    connect(this, SIGNAL(sigHideAll()), pWin, SLOT(hideAllSlot()));
    connect(this, SIGNAL(sigTouxiangShow()), pWin, SLOT(touxiangShowSlot()));
}

CurrentThread::~CurrentThread() {
    pWin = nullptr ;

    if ( mSocket != nullptr ) {
        mSocket->close();
    }

    if ( db.open() )
        db.close() ;
}

void CurrentThread::run() {
    emit udpBind();

    while(true) {
        //        qDebug() << this << __FUNCTION__ << __LINE__ ;

        //n秒钟后重新获取游戏状态
        if ( !isFirstTime )
            sleep(pWin->config_game_event_interval.toULong());

        isFirstTime = false ;

        // 连接数据库
        while( !connect_db() ) {
            sleep(pWin->config_db_reconnect_interval.toULong());
        }

        QSqlQuery q("select * from session_state", db);
        if(q.next()) {
            session_next = q.value(0).toInt();
            state_next = q.value(1).toInt();
        }

        //sessin不同的情况下，直接赋值sessoin和状态返回
        if ( session_next != session_prev ) {
            session_prev = session_next ;
            state_prev = state_next;
            //n秒钟后重新获取游戏状态
            continue;
        }

        //游戏开始
        if ( state_prev != 2 && state_next == 2 ) {
            state_prev = 2 ;
            qDebug() << this << __FUNCTION__ << __LINE__ << "Game start event found .";

            {
                rmutex lock(mutex);
                pWin->game_state = RUNNING;
                running_session_id = session_next ;

                //切换到正在进行状态
                stateToggle();
            }

            rank1_seat = 0 ;
            rank2_seat = 0 ;
            rank3_seat = 0 ;

            score1 = 0 ;
            score2 = 0 ;
            score3 = 0 ;

            isGameHasStarted = true ;
            continue;
        }

        //游戏结束
        if ( state_prev == 2 && state_next != 2 ) {
            qDebug() << this << __FUNCTION__ << __LINE__ << "Game over event found .";

            running_session_id = -1 ;
            state_prev = -1;

            rmutex lock(mutex);

            if ( isGameHasStarted ) {
                pWin->game_state = OVER ;
                pWin->gameOverTime.start();
            }

        }
    }
}

bool CurrentThread::connect_db() {
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    if ( db.isOpen() )
        return true ;

    db = QSqlDatabase::addDatabase("QMYSQL", "current");
    db.setHostName(pWin->config_host);
    db.setPort(pWin->config_port.toInt());
    db.setUserName(pWin->config_user);
    db.setPassword(pWin->config_password);
    db.setDatabaseName(pWin->config_database);

    if(!db.open()) {
        qDebug() << this << __FUNCTION__ << __LINE__ <<"Connect MySql error!" ;
        return false;
    }

    qDebug()<<"Connect MySql success!";

    return true ;
}

void CurrentThread::getAvatar( const int rank1_seat,
                               const int rank2_seat,
                               const int rank3_seat){
    QString sql = QString().sprintf(
                "select player_avatar from record where session_id=%d and seat_id=%d",
                running_session_id,
                rank1_seat );
    QSqlQuery q(sql,db);
    if (q.next())
        pWin->picJin.loadFromData(q.value(0).toByteArray(), "PNG");

    sql = QString().sprintf(
                "select player_avatar from record where session_id=%d and seat_id=%d",
                running_session_id,
                rank2_seat );
    q.exec(sql) ;
    if (q.next())
        pWin->picYin.loadFromData(q.value(0).toByteArray(), "PNG");

    sql = QString().sprintf(
                "select player_avatar from record where session_id=%d and seat_id=%d",
                running_session_id,
                rank3_seat );
    q.exec(sql) ;
    if (q.next())
        pWin->picTong.loadFromData(q.value(0).toByteArray(), "PNG");
}

void CurrentThread::getScore(){

    //用于判断新数据是否发生了变化
    bool flag = false;

    QByteArray byte_data;
    while(mSocket->hasPendingDatagrams())
    {
        byte_data.resize(static_cast<int>(mSocket->bytesAvailable()));
        mSocket->readDatagram(byte_data.data(), byte_data.size());
        //qDebug() << byte_data ;

        //解析，只需要前三名数据
        Common::PlayerScore obj;
        bool isGet = obj.ParseFromString(byte_data.data());
        qDebug() << isGet << " : " << obj.values_size() ;

        for(uint32_t i=0; i < uint32_t(obj.values_size()) ; i++ ) {
            const Common::PlayerStats& ps = obj.values(int(i));
            qDebug() << "i=" << i+1 ;
            qDebug() << "score=" << ps.score();
            qDebug() << "rank=" << ps.rank();
            if( ps.rank() == 1 ){
                if (rank1_seat != i) {
                    flag = true ;
                    rank1_seat = i;
                }

                if ( score1 != ps.score() ) {
                    flag = true;
                    score1 = ps.score() ;
                    pWin->scoreJin = QString::number(ps.score());
                }
            }
            else if (ps.rank() == 2) {
                if (rank2_seat != i) {
                    flag = true ;
                    rank2_seat = i;
                }

                if ( score2 != ps.score() ) {
                    flag = true;
                    score2 = ps.score() ;
                    pWin->scoreYin = QString::number(ps.score());
                }
            }
            else if (ps.rank() == 3) {
                if (rank3_seat != i) {
                    flag = true ;
                    rank3_seat = i;
                }

                if ( score3 != ps.score() ) {
                    flag = true;
                    score3 = ps.score() ;
                    pWin->scoreTong = QString::number(ps.score());
                }
            }
        }

        getAvatar(int(rank1_seat),
                  int(rank2_seat),
                  int(rank3_seat));

        //切换头像和分数
        if ( flag && pWin->game_state == RUNNING )
            touXiangToggle();
    }
}


void CurrentThread::stateToggle() {
    emit sigHideAll();

    //启动正在进行动画
    pWin->zhengzaijinxingThread->start();
    pWin->pianmingThread->start();
    pWin->kuangThread->start();
    pWin->yuanThread->start();
    pWin->yuanguangThread->start();
    pWin->pianmingThread->start();
    sleep(1);
    pWin->kuangThread->start();
    pWin->yuanThread->start();
    pWin->yuanguangThread->start();
}

void CurrentThread::touXiangToggle() {
    //启动头像切换动画
    pWin->qiehuantouxiangThread->start();

    //显示头像
    msleep(600);
    emit sigTouxiangShow();

    //显示数字
    pWin->shuziThread->start();
}
