#include "historythread.h"

HistoryThread::HistoryThread(Widget* p) : pWin(p),
    isFirstTime(true)
{
    connect(this, SIGNAL(sigHideAll()), pWin, SLOT(hideAllSlot()));
    connect(this, SIGNAL(sigTouxiangShow()), pWin, SLOT(touxiangShowSlot()));
}

HistoryThread::~HistoryThread(){
    pWin = nullptr ;

    if ( db.open() )
        db.close() ;
}

void HistoryThread::run() {
    while(true) {
        //        qDebug() << this << __FUNCTION__ << __LINE__ ;
        if ( !isFirstTime )
            sleep(pWin->config_history_refresh_interval.toULong());

        isFirstTime = false ;

        {
            rmutex lock(mutex);
            //游戏过程中不刷新周月季数据
            if (pWin->game_state == RUNNING ) {
                continue;
            }
        }

        // 连接数据库
        while ( !connect_db() ) {
            sleep(pWin->config_db_reconnect_interval.toULong());
        }

        //一次性获取周月季数据
        getZhouData() ;
        getYueData() ;
        getJiData() ;

        {
            rmutex lock(mutex);
            switch ( pWin->game_state.operator int() ) {
            case RUNNING : {
                break;
            }
                //依旧n分钟后，再切换到周月季状态
            case OVER : {
                qDebug() << pWin->game_state << " " << pWin->gameOverTime.elapsed() ;
                if ( pWin->gameOverTime.elapsed() < pWin->config_game_over_wait_interval.toInt()*1000 )
                    break ;

                pWin->game_state=ZHOU;
                zhouState();
                break ;
            }
            case ZHOU : {
                pWin->game_state=YUE;
                yueState();
                break;
            }
            case YUE : {
                pWin->game_state=JI;
                jiState();
                break;
            }
            case JI : {
                pWin->game_state=ZHOU;
                zhouState();
                break;
            }
            default: {
                pWin->game_state=ZHOU;
                zhouState();
                break;
            }
            }
        }
    }
}


bool HistoryThread::connect_db() {
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    if ( db.isOpen() )
        return true ;

    db = QSqlDatabase::addDatabase("QMYSQL", "history");
    db.setHostName(pWin->config_host);
    db.setPort(pWin->config_port.toInt());
    db.setUserName(pWin->config_user);
    db.setPassword(pWin->config_password);
    db.setDatabaseName(pWin->config_database);

    if(!db.open()) {
        qDebug() << this << __FUNCTION__ << __LINE__ <<"Connect MySql error!" ;
        return false;
    }

    qDebug()<<"Connect MySql success!";

    return true ;
}


void HistoryThread::getZhouData(){
    QString sql = QString().sprintf(
                "select player_avatar, player_score from record where session_id in (select id from session where start_time > '%s' and end_time < '%s') order by cast(player_score as signed) desc limit 3",
                getZhouBegin().toLocal8Bit().data(),
                getZhouEnd().toLocal8Bit().data());

    QSqlQuery q(sql,db);
    if (q.next()) {
        pWin->picJin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreJin = q.value("player_score").toString();
    }

    if (q.next()) {
        pWin->picYin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreYin = q.value("player_score").toString();
    }

    if (q.next()) {
        pWin->picTong.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreTong = q.value("player_score").toString();
    }
}

void HistoryThread::getYueData(){
    QString sql = QString().sprintf(
                "select player_avatar, player_score from record where session_id in (select id from session where start_time > '%s' and end_time < '%s') order by cast(player_score as signed) desc limit 3",
                getYueBegin().toLocal8Bit().data(),
                getYueEnd().toLocal8Bit().data());

    QSqlQuery q(sql,db);
    if (q.next()){
        pWin->picJin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreJin = q.value("player_score").toString();
    }

    if (q.next()){
        pWin->picYin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreYin = q.value("player_score").toString();
    }

    if (q.next()){
        pWin->picTong.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreTong = q.value("player_score").toString();
    }
}

void HistoryThread::getJiData(){
    QString sql = QString().sprintf(
                "select player_avatar, player_score from record where session_id in (select id from session where start_time > '%s' and end_time < '%s') order by cast(player_score as signed) desc limit 3",
                getJiBegin().toLocal8Bit().data(),
                getJiEnd().toLocal8Bit().data());

    QSqlQuery q(sql,db);
    if (q.next()) {
        pWin->picJin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreJin = q.value("player_score").toString();
    }

    if (q.next()) {
        pWin->picYin.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreYin = q.value("player_score").toString();
    }

    if (q.next()) {
        pWin->picTong.loadFromData(q.value("player_avatar").toByteArray(), "PNG");
        pWin->scoreTong = q.value("player_score").toString();
    }
}

QString HistoryThread::getZhouBegin() {
    QString sql = "SELECT DATE_FORMAT( SUBDATE(CURDATE(),DATE_FORMAT(CURDATE(),'%w')-1), '%Y-%m-%d 00:00:00') AS '本周一'";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本周一 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

QString HistoryThread::getZhouEnd() {
    QString sql = "SELECT DATE_FORMAT( DATE_ADD(SUBDATE(CURDATE(), WEEKDAY(CURDATE())), INTERVAL 6 DAY), '%Y-%m-%d 23:59:59') AS '本周末'";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本周末 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

QString HistoryThread::getYueBegin() {
    QString sql = "SELECT DATE_FORMAT( CURDATE(), '%Y-%m-01 00:00:00') AS '本月初'";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本月初 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

QString HistoryThread::getYueEnd() {
    QString sql = "SELECT DATE_FORMAT( LAST_DAY(CURDATE()), '%Y-%m-%d 23:59:59') AS '本月末'";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本月末 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

QString HistoryThread::getJiBegin() {
    QString sql = "select concat(DATE_FORMAT(LAST_DAY(MAKEDATE(EXTRACT(YEAR FROM CURDATE()),1) + interval QUARTER(CURDATE())*3-3 month),'%Y-%m-'),'01 00:00:00')";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本季初 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

QString HistoryThread::getJiEnd() {
    QString sql = "select concat(DATE_FORMAT(LAST_DAY(MAKEDATE(EXTRACT(YEAR FROM CURDATE()),1) + interval QUARTER(CURDATE())*3-1 month),'%Y-%m-%d'),' 23:59:59')";
    QSqlQuery q(sql,db);
    if (q.next())
    {
        //qDebug() << "本季末 = " << q.value(0).toString();
        return q.value(0).toString();
    }

    return "";
}

void HistoryThread::stateToggle() {
    //qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigHideAll();

    //启动名人堂动画
    pWin->faguangThread->start();
    pWin->guangxianThread->start();
    pWin->xingxingThread->start();
    pWin->xunzhangThread->start();
    pWin->mingrentangThread->start();

    pWin->pianmingThread->start();

    sleep(1);

    pWin->kuangThread->start();
    pWin->yuanThread->start();
    pWin->yuanguangThread->start();

    //启动“本x"动画
    pWin->huizhanglishiThread->start();
}

void HistoryThread::zhouState() {
    qDebug() << this << __FUNCTION__ << __LINE__ ;

    stateToggle();
    pWin->zhouThread->start();
    touXiangToggle();
}

void HistoryThread::yueState() {
    qDebug() << this << __FUNCTION__ << __LINE__ ;

    stateToggle();
    pWin->yueThread->start();
    touXiangToggle();
}

void HistoryThread::jiState() {
    qDebug() << this << __FUNCTION__ << __LINE__ ;

    stateToggle();
    pWin->jiThread->start();
    touXiangToggle();
}


void HistoryThread::touXiangToggle() {
    //启动头像切换动画
    pWin->qiehuantouxiangThread->start();

    //显示头像
    msleep(600);
    emit sigTouxiangShow();

    //显示数字
    pWin->shuziThread->start();
}
