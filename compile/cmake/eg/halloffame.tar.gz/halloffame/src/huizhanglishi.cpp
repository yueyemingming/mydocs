#include "huizhanglishi.h"

const int HuiZhangLiShi::max_pic_size = 9;

HuiZhangLiShi::HuiZhangLiShi(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(huizhanglishiShowSlot(const int)) );
}

void HuiZhangLiShi::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0);
}
