#include "ji.h"

const int Ji::max_pic_size = 0;

Ji::Ji(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(jiShowSlot(const int)) );
}

void Ji::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;


    emit sigShow(0);
}
