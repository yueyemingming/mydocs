#include "kuang.h"

const int Kuang::max_pic_size = 10;

Kuang::Kuang(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(kuangShowSlot(const int)) );
}

void Kuang::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;
    int i = 0 ;
    while(true) {

        emit sigShow(i);

        i++;
        if ( i >= max_pic_size+1 )
            break;

        QThread::msleep(100);
    }
}
