#include "mingrentang.h"

const int MingRenTang::max_pic_size = 25;

MingRenTang::MingRenTang(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(mingrentangShowSlot(const int)) );
}

void MingRenTang::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    int i = 0 ;
    while(true) {
        emit sigShow(i);

        i++;
        if ( i >= max_pic_size+1 )
            break;

        QThread::msleep(100);
    }
}
