#include "qiehuantouxiang.h"

const int QieHuanTouXiang::max_pic_size = 28;

QieHuanTouXiang::QieHuanTouXiang(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(qiehuantouxiangShowSlot(const int)) );
}

void QieHuanTouXiang::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    int i = 0 ;
    while(true) {
        emit sigShow(i);

        i++;
        if ( i >= max_pic_size+1 )
            break;

        QThread::msleep(120);
    }
}
