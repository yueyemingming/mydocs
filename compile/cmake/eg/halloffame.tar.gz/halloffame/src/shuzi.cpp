#include "shuzi.h"

const int ShuZi::max_pic_size = 10;

ShuZi::ShuZi(Widget* p) : pWin(p)
{
  connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(shuziShowSlot(const int)) );
}

void ShuZi::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0) ;
}
