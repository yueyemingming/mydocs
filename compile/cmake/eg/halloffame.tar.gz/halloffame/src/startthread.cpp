#include "startthread.h"

StartThread::StartThread(Widget* p) : pWin(p)
{
    connect(this, SIGNAL(sigHideAll()), pWin, SLOT(hideAllSlot()));
}

void StartThread::run() {

    emit sigHideAll();

    pWin->faguangThread->start();
    pWin->guangxianThread->start();
    pWin->xingxingThread->start();

    pWin->pianmingThread->start();

    sleep(1);

    pWin->xunzhangThread->start();
    pWin->mingrentangThread->start();

    pWin->kuangThread->start();
    pWin->yuanThread->start();
    pWin->yuanguangThread->start();

    sleep(1);

    //实时刷新周月季数据库
    pWin->historyThread->start();

    //游戏监听事件
    pWin->currentThread->start();
}
