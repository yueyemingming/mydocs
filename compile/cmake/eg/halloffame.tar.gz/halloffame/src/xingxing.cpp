#include "xingxing.h"

const int XingXing::max_pic_size = 46;

XingXing::XingXing(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(xingxingShowSlot(const int)) );
}

void XingXing::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    int i = 0 ;
    while(true) {
        emit sigShow(i);

        i++;
        if ( i >= max_pic_size+1 )
            break;

        QThread::msleep(100);
    }
}
