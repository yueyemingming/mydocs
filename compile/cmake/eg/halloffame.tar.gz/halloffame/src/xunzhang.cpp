#include "xunzhang.h"

const int XunZhang::max_pic_size =0;

XunZhang::XunZhang(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(xunzhangShowSlot(const int)) );
}

void XunZhang::run() {
    emit sigShow(0);
}
