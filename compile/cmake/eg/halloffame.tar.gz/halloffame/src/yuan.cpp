#include "yuan.h"

const int Yuan::max_pic_size = 0;

Yuan::Yuan(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(yuanShowSlot(const int)) );
}

void Yuan::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0);
}
