#include "yue.h"

const int Yue::max_pic_size = 0;

Yue::Yue(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(yueShowSlot(const int)) );
}

void Yue::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0);
}
