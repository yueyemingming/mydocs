#include "zhengzaijinxing.h"

const int ZhengZaiJinXing::max_pic_size = 0;

ZhengZaiJinXing::ZhengZaiJinXing(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(zhengzaijinxingShowSlot(const int)) );
}

void ZhengZaiJinXing::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0);
}
