#include "zhou.h"

const int Zhou::max_pic_size = 9;

Zhou::Zhou(Widget* p) : pWin(p)
{
    connect( this, SIGNAL(sigShow(const int)), pWin, SLOT(zhouShowSlot(const int)) );
}

void Zhou::run(){
    //    qDebug() << this << __FUNCTION__ << __LINE__ ;

    emit sigShow(0);
}
