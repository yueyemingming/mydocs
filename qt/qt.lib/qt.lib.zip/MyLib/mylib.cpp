#include "mylib.h"
#include <iostream>

MyLib::MyLib()
{
    std::cout << "new lib" << std::endl ;
}
