#ifndef MYLIB_H
#define MYLIB_H

#include "mylib_global.h"
class MYLIBSHARED_EXPORT MyLib
{

public:
    MyLib();
};

#endif // MYLIB_H
