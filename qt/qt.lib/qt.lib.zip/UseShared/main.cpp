#include <QCoreApplication>
#include "mylib.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    MyLib my;

    return a.exec();
}
