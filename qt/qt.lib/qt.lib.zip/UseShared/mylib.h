#ifndef MYLIB_H
#define MYLIB_H

class MyLib
{

public:
    MyLib();
};

#endif // MYLIB_H
