#include <QCoreApplication>
#include "mylib.h"
#include <iostream>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    MyLib my;

    std::cout << "1111111111" << std::endl ;

    return a.exec();
}
